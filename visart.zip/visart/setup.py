from setuptools import setup

setup(name='visart',
      version='0.9',
      description='Minimalistic plots for data analisys',
      packages=['visart'],
      author_email='vlad.zhyvov@gmail.com',
      zip_safe=False)
